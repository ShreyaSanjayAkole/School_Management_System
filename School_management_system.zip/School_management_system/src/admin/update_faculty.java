package admin;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import database.connection;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class update_faculty extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JTextField tfaddress;
    private JTextField tfemail;
    private JTextField tfphone;
    private JComboBox comboBox;
	private JLabel labelempId;
	private JTextField tfcourse;
	private JTextField tfbranch;
	int sid;
	private JLabel labelname,labelfather,labeldob,labelaadhar,labeleid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					update_faculty frame = new update_faculty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public update_faculty() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 50,900, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		 
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Update Teacher Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 4;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("Select Employee ID: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 2;
		gbc_lblNewLabel_3.gridy = 3;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		comboBox = new JComboBox();
		try {
		 	Connection con=connection.getcon();
		 	Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from teacher");
            
            while(rs.next()) {
            	
            	int id=rs.getInt("eid");
            	String eid=Integer.toString(id);
            	comboBox.addItem(eid);;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		try {
			String selectid=(String)comboBox.getSelectedItem();
			sid=Integer.parseInt(selectid);
			
			Connection con=connection.getcon();
            String query = "select * from teacher where eid=? ";
            PreparedStatement ins=con.prepareStatement(query);
            ins.setInt(1, sid);
            ResultSet rs = ins.executeQuery();
            while(rs.next()) {
                labelname.setText(rs.getString("name"));
                labelfather.setText(rs.getString("father"));
                labeldob.setText(rs.getString("dob"));
                tfaddress.setText(rs.getString("address"));
                tfphone.setText(rs.getString("phone"));
                tfemail.setText(rs.getString("email"));
                labelaadhar.setText(rs.getString("adhar"));
                labeleid.setText(rs.getString("eid"));
                tfcourse.setText(rs.getString("Qua"));
                tfbranch.setText(rs.getString("depart"));
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
		
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				try {
					String selectid=(String)comboBox.getSelectedItem();
					sid=Integer.parseInt(selectid);
					
					Connection con=connection.getcon();
		            String query = "select * from teacher where eid=? ";
		            PreparedStatement ins=con.prepareStatement(query);
		            ins.setInt(1, sid);
		            ResultSet rs = ins.executeQuery();
		            while(rs.next()) {
		                labelname.setText(rs.getString("name"));
		                labelfather.setText(rs.getString("father"));
		                labeldob.setText(rs.getString("dob"));
		                tfaddress.setText(rs.getString("address"));
		                tfphone.setText(rs.getString("phone"));
		                tfemail.setText(rs.getString("email"));
		                labelaadhar.setText(rs.getString("adhar"));
		                labeleid.setText(rs.getString("eid"));
		                tfcourse.setText(rs.getString("Qua"));
		                tfbranch.setText(rs.getString("depart"));
		            }
		        } catch (Exception e2) {
		            e2.printStackTrace();
		        }
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 3;
		gbc_comboBox.gridy = 3;
		contentPane.add(comboBox, gbc_comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 6;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		labelname = new JLabel("");
		labelname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_labelname = new GridBagConstraints();
		gbc_labelname.insets = new Insets(0, 0, 5, 5);
		gbc_labelname.gridx = 3;
		gbc_labelname.gridy = 6;
		contentPane.add(labelname, gbc_labelname);
		
		JLabel lblNewLabel_7 = new JLabel("Father's Name");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.gridx = 4;
		gbc_lblNewLabel_7.gridy = 6;
		contentPane.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		labelfather = new JLabel("");
		labelfather.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_labelfather = new GridBagConstraints();
		gbc_labelfather.insets = new Insets(0, 0, 5, 5);
		gbc_labelfather.gridx = 5;
		gbc_labelfather.gridy = 6;
		contentPane.add(labelfather, gbc_labelfather);
		
		 
		
		JLabel lblNewLabel_2 = new JLabel("Employee ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 8;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		labeleid = new JLabel("");
		labeleid.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_labeleid = new GridBagConstraints();
		gbc_labeleid.insets = new Insets(0, 0, 5, 5);
		gbc_labeleid.gridx = 3;
		gbc_labeleid.gridy = 8;
		contentPane.add(labeleid, gbc_labeleid);
		
		JLabel lblNewLabel_8 = new JLabel("Date of Birth");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 4;
		gbc_lblNewLabel_8.gridy = 8;
		contentPane.add(lblNewLabel_8, gbc_lblNewLabel_8);
		
		labeldob = new JLabel("");
		labeldob.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_labeldob = new GridBagConstraints();
		gbc_labeldob.insets = new Insets(0, 0, 5, 5);
		gbc_labeldob.gridx = 5;
		gbc_labeldob.gridy = 8;
		contentPane.add(labeldob, gbc_labeldob);
		
		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 2;
		gbc_lblNewLabel_4.gridy = 10;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		tfaddress = new JTextField();
		tfaddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfaddress = new GridBagConstraints();
		gbc_tfaddress.insets = new Insets(0, 0, 5, 5);
		gbc_tfaddress.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfaddress.gridx = 3;
		gbc_tfaddress.gridy = 10;
		contentPane.add(tfaddress, gbc_tfaddress);
		tfaddress.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Phone");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
		gbc_lblNewLabel_9.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_9.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_9.gridx = 4;
		gbc_lblNewLabel_9.gridy = 10;
		contentPane.add(lblNewLabel_9, gbc_lblNewLabel_9);
		
		tfphone = new JTextField();
		tfphone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfphone = new GridBagConstraints();
		gbc_tfphone.insets = new Insets(0, 0, 5, 5);
		gbc_tfphone.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfphone.gridx = 5;
		gbc_tfphone.gridy = 10;
		contentPane.add(tfphone, gbc_tfphone);
		tfphone.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Email Id");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 2;
		gbc_lblNewLabel_5.gridy = 12;
		contentPane.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		tfemail = new JTextField();
		tfemail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfemail = new GridBagConstraints();
		gbc_tfemail.insets = new Insets(0, 0, 5, 5);
		gbc_tfemail.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfemail.gridx = 3;
		gbc_tfemail.gridy = 12;
		contentPane.add(tfemail, gbc_tfemail);
		tfemail.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Aadhar No.");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_10 = new GridBagConstraints();
		gbc_lblNewLabel_10.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_10.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_10.gridx = 4;
		gbc_lblNewLabel_10.gridy = 12;
		contentPane.add(lblNewLabel_10, gbc_lblNewLabel_10);
		
		labelaadhar = new JLabel("");
		labelaadhar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_labelaadhar = new GridBagConstraints();
		gbc_labelaadhar.insets = new Insets(0, 0, 5, 5);
		gbc_labelaadhar.gridx = 5;
		gbc_labelaadhar.gridy = 12;
		contentPane.add(labelaadhar, gbc_labelaadhar);
		
		JLabel lblNewLabel_6 = new JLabel("Qualification");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 2;
		gbc_lblNewLabel_6.gridy = 14;
		contentPane.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		
		
		tfcourse = new JTextField();
		tfcourse.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfcourse = new GridBagConstraints();
		gbc_tfcourse.insets = new Insets(0, 0, 5, 5);
		gbc_tfcourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfcourse.gridx = 3;
		gbc_tfcourse.gridy = 14;
		contentPane.add(tfcourse, gbc_tfcourse);
		tfcourse.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Department");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_11 = new GridBagConstraints();
		gbc_lblNewLabel_11.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_11.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_11.gridx = 4;
		gbc_lblNewLabel_11.gridy = 14;
		contentPane.add(lblNewLabel_11, gbc_lblNewLabel_11);
		
		tfbranch = new JTextField();
		tfbranch.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfbranch = new GridBagConstraints();
		gbc_tfbranch.insets = new Insets(0, 0, 5, 5);
		gbc_tfbranch.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfbranch.gridx = 5;
		gbc_tfbranch.gridy = 14;
		contentPane.add(tfbranch, gbc_tfbranch);
		tfbranch.setColumns(10);
		
		
		JButton submit = new JButton("Update");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	            String address = tfaddress.getText();
	            String phone = tfphone.getText();
	            String email = tfemail.getText();
	            String course = tfcourse.getText();
	            String branch = tfbranch.getText();
	            
                try
                {
               	 Connection con=connection.getcon();
               	String query = "update teacher set address=?, phone=?, email=?, Qua=?, depart=? where eid=?";
               	 PreparedStatement ins=con.prepareStatement(query);
               	 ins.setString(1, address);
               	 ins.setString(2,phone);
               	 ins.setString(3,email);
               	 ins.setString(4,course);
               	 ins.setString(5,branch);
               	 ins.setInt(6,sid);
               	 ins.executeUpdate();
               	 JOptionPane.showMessageDialog(null, "Teacher Details Updated Successfully");
               }
                catch (Exception e1) {
               	 JOptionPane.showMessageDialog(null, e1);
                }
			}
		});
		
		
		submit.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_submit = new GridBagConstraints();
		gbc_submit.insets = new Insets(0, 0, 5, 5);
		gbc_submit.gridx = 3;
		gbc_submit.gridy = 17;
		contentPane.add(submit, gbc_submit);
		
		JButton cancle = new JButton("Cancel");
		cancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		cancle.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_cancle = new GridBagConstraints();
		gbc_cancle.insets = new Insets(0, 0, 5, 5);
		gbc_cancle.gridx = 4;
		gbc_cancle.gridy = 17;
		contentPane.add(cancle, gbc_cancle);
	}

}
