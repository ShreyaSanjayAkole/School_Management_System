package admin;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import database.connection;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class add_faculty extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox cbcourse,cbbranch;
	private JLabel labelempId;
	private JDateChooser dcdob;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					add_faculty frame = new add_faculty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Random ran = new Random();
    long first4 = Math.abs((ran.nextLong() % 9000L) + 1000L);
    private JTextField tfname;
    private JTextField tfaddress;
    private JTextField tfemail;
    private JTextField tffname;
    private JTextField tfphone;
    private JTextField tfaadhar;
    private JTextField eid;
	/**
	 * Create the frame.
	 */
	public add_faculty() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 50,900, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		 
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("New Teacher Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 4;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Employee ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 3;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		eid = new JTextField();
		eid.setText("101"+first4);
		eid.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_eid = new GridBagConstraints();
		gbc_eid.insets = new Insets(0, 0, 5, 5);
		gbc_eid.fill = GridBagConstraints.HORIZONTAL;
		gbc_eid.gridx = 3;
		gbc_eid.gridy = 3;
		contentPane.add(eid, gbc_eid);
		eid.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Father's Name");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.gridx = 4;
		gbc_lblNewLabel_7.gridy = 3;
		contentPane.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		tffname = new JTextField();
		tffname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tffname = new GridBagConstraints();
		gbc_tffname.insets = new Insets(0, 0, 5, 5);
		gbc_tffname.fill = GridBagConstraints.HORIZONTAL;
		gbc_tffname.gridx = 5;
		gbc_tffname.gridy = 3;
		contentPane.add(tffname, gbc_tffname);
		tffname.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 5;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		tfname = new JTextField();
		tfname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfname = new GridBagConstraints();
		gbc_tfname.insets = new Insets(0, 0, 5, 5);
		gbc_tfname.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfname.gridx = 3;
		gbc_tfname.gridy = 5;
		contentPane.add(tfname, gbc_tfname);
		tfname.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Date of Birth");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 4;
		gbc_lblNewLabel_8.gridy = 5;
		contentPane.add(lblNewLabel_8, gbc_lblNewLabel_8);
		
		dcdob = new JDateChooser();
		GridBagConstraints gbc_dcdob = new GridBagConstraints();
		gbc_dcdob.insets = new Insets(0, 0, 5, 5);
		gbc_dcdob.fill = GridBagConstraints.BOTH;
		gbc_dcdob.gridx = 5;
		gbc_dcdob.gridy = 5;
		contentPane.add(dcdob, gbc_dcdob);
		
		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 2;
		gbc_lblNewLabel_4.gridy = 7;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		tfaddress = new JTextField();
		tfaddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfaddress = new GridBagConstraints();
		gbc_tfaddress.insets = new Insets(0, 0, 5, 5);
		gbc_tfaddress.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfaddress.gridx = 3;
		gbc_tfaddress.gridy = 7;
		contentPane.add(tfaddress, gbc_tfaddress);
		tfaddress.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Phone");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
		gbc_lblNewLabel_9.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_9.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_9.gridx = 4;
		gbc_lblNewLabel_9.gridy = 7;
		contentPane.add(lblNewLabel_9, gbc_lblNewLabel_9);
		
		tfphone = new JTextField();
		tfphone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfphone = new GridBagConstraints();
		gbc_tfphone.insets = new Insets(0, 0, 5, 5);
		gbc_tfphone.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfphone.gridx = 5;
		gbc_tfphone.gridy = 7;
		contentPane.add(tfphone, gbc_tfphone);
		tfphone.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Email Id");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 2;
		gbc_lblNewLabel_5.gridy = 9;
		contentPane.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		tfemail = new JTextField();
		tfemail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfemail = new GridBagConstraints();
		gbc_tfemail.insets = new Insets(0, 0, 5, 5);
		gbc_tfemail.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfemail.gridx = 3;
		gbc_tfemail.gridy = 9;
		contentPane.add(tfemail, gbc_tfemail);
		tfemail.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Aadhar No.");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_10 = new GridBagConstraints();
		gbc_lblNewLabel_10.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_10.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_10.gridx = 4;
		gbc_lblNewLabel_10.gridy = 9;
		contentPane.add(lblNewLabel_10, gbc_lblNewLabel_10);
		
		tfaadhar = new JTextField();
		tfaadhar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tfaadhar = new GridBagConstraints();
		gbc_tfaadhar.insets = new Insets(0, 0, 5, 5);
		gbc_tfaadhar.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfaadhar.gridx = 5;
		gbc_tfaadhar.gridy = 9;
		contentPane.add(tfaadhar, gbc_tfaadhar);
		tfaadhar.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Qualification");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 2;
		gbc_lblNewLabel_6.gridy = 11;
		contentPane.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		String course[] = {"B.Tech", "BBA", "BCA", "Bsc", "Msc", "MBA", "MCA", "MCom", "MA", "BA"};
		cbcourse = new JComboBox(course);
		cbcourse.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_cbcourse = new GridBagConstraints();
		gbc_cbcourse.insets = new Insets(0, 0, 5, 5);
		gbc_cbcourse.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbcourse.gridx = 3;
		gbc_cbcourse.gridy = 11;
		contentPane.add(cbcourse, gbc_cbcourse);
		
		JLabel lblNewLabel_11 = new JLabel("Department");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_11 = new GridBagConstraints();
		gbc_lblNewLabel_11.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_11.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_11.gridx = 4;
		gbc_lblNewLabel_11.gridy = 11;
		contentPane.add(lblNewLabel_11, gbc_lblNewLabel_11);
		
		String branch[] = {"Computer Science", "Electronics", "Mechanical", "Civil", "IT"};
		cbbranch = new JComboBox(branch);
		cbbranch.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_cbbranch = new GridBagConstraints();
		gbc_cbbranch.insets = new Insets(0, 0, 5, 5);
		gbc_cbbranch.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbbranch.gridx = 5;
		gbc_cbbranch.gridy = 11;
		contentPane.add(cbbranch, gbc_cbbranch);
		
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = tfname.getText();
                String fname = tffname.getText();
                String rollno = eid.getText();
                int rno=Integer.parseInt(rollno);
                String dob = ((JTextField) dcdob.getDateEditor().getUiComponent()).getText();
                String address = tfaddress.getText();
                String phone = tfphone.getText();
                long pho=Long.parseLong(phone);
                String email = tfemail.getText();
                String aadhar = tfaadhar.getText();
                long a=Long.parseLong(aadhar);
                String course = (String) cbcourse.getSelectedItem();
                String branch = (String) cbbranch.getSelectedItem();
                
                try
                {
               	 Connection con=connection.getcon();
               	 String insert="insert into teacher(eid,name,address,email,Qua,father,dob,phone,adhar,depart) values(?,?,?,?,?,?,?,?,?,?)";
               	 PreparedStatement ins=con.prepareStatement(insert);
               	 ins.setInt(1, rno);
               	 ins.setString(2,name);
               	 ins.setString(3,address);
               	 ins.setString(4,email);
               	 ins.setString(5,course);
               	 ins.setString(6,fname);
               	 ins.setString(7,dob);
               	 ins.setLong(8,pho);
               	 ins.setLong(9,a);
               	 ins.setString(10,branch);
               	 ins.executeUpdate();
               	 JOptionPane.showMessageDialog(null, "Teacher Details Inserted Successfully");
               }
                catch (Exception e1) {
               	 JOptionPane.showMessageDialog(null, e1);
                }
			}
		});
		submit.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_submit = new GridBagConstraints();
		gbc_submit.insets = new Insets(0, 0, 5, 5);
		gbc_submit.gridx = 3;
		gbc_submit.gridy = 14;
		contentPane.add(submit, gbc_submit);
		
		JButton cancle = new JButton("Cancel");
		cancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		cancle.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_cancle = new GridBagConstraints();
		gbc_cancle.insets = new Insets(0, 0, 5, 5);
		gbc_cancle.gridx = 4;
		gbc_cancle.gridy = 14;
		contentPane.add(cancle, gbc_cancle);
	        
	        
	        
	        
	}
}
