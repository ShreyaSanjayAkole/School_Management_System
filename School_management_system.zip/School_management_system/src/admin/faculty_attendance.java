package admin;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;


import database.connection;

public class faculty_attendance extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JDateChooser dateChooser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					faculty_attendance frame = new faculty_attendance();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public faculty_attendance() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnNewButton_1 = new JButton("back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new admin_dashboard().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 0;
		gbc_btnNewButton_1.gridy = 0;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Search");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 3;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd-MM-yyyy");
		GridBagConstraints gbc_dateChooser = new GridBagConstraints();
		gbc_dateChooser.gridwidth = 15;
		gbc_dateChooser.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooser.fill = GridBagConstraints.BOTH;
		gbc_dateChooser.gridx = 2;
		gbc_dateChooser.gridy = 3;
		contentPane.add(dateChooser, gbc_dateChooser);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
				table.setModel(new DefaultTableModel(
						new Object[][] {
							{"Name", "Department", "Date", "In-Time","Out-Time", "Status"},
						},
						new String[] {
							"New column", "New column", "New column", "New column", "New column", "New column"
						}
					));
				String selectdate =((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
				try
				{
					Connection con=connection.getcon();
					String select1="select * from user_attendance;";
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery(select1);
					
					DefaultTableModel model= (DefaultTableModel) table.getModel();
					
					String name,dept,date,intime,outtime,status;
					int temp=0;
					while( rs.next())
					{
						name=rs.getString(3);
						dept=rs.getString(4);
						date=rs.getString(5);
						intime=rs.getString(6);
						outtime=rs.getString(7);
						status=rs.getString(8);
						if(selectdate.equals(date))
						{
							String[] row= {name,dept,date,intime,outtime,status};
							model.addRow(row);
							temp++;
						}
												
					}
					if(temp==0)
					{
						JOptionPane.showMessageDialog(null, "No data available");
					}
					table.setFont(new Font("Tahoma", Font.PLAIN, 20));
					table.getColumnModel().getColumn(0).setPreferredWidth(120);
					table.getColumnModel().getColumn(1).setPreferredWidth(120);
					table.getColumnModel().getColumn(2).setPreferredWidth(120);
					table.getColumnModel().getColumn(4).setPreferredWidth(100);
				}
				catch(Exception el)
				{
					JOptionPane.showMessageDialog(null, el);
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 17;
		gbc_btnNewButton.gridy = 3;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_2 = new JButton("View");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new chart().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_2.gridx = 18;
		gbc_btnNewButton_2.gridy = 3;
		contentPane.add(btnNewButton_2, gbc_btnNewButton_2);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridheight = 12;
		gbc_panel.gridwidth = 23;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 4;
		contentPane.add(panel, gbc_panel);
		
		
		table = new JTable();
		table.setModel(new DefaultTableModel());
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Name", "Department", "Date","In-Time","Out-Time", "Status"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column","New column"
			}
		));
		table.setFont(new Font("Tahoma", Font.PLAIN, 20));
		table.setRowHeight(30);
		String d=new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		try
		{
			Connection con=connection.getcon();
			String select1="select * from user_attendance;";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(select1);
			ResultSetMetaData rsmd=rs.getMetaData();
			DefaultTableModel model= (DefaultTableModel) table.getModel();
			
			
			String name,dept,date,intime,outtime,status;
			while( rs.next())
			{
				name=rs.getString(3);
				dept=rs.getString(4);
				date=rs.getString(5);
				intime=rs.getString(6);
				outtime=rs.getString(7);
				status=rs.getString(8);
				if(d.equals(date))
				{
					String[] row= {name,dept,date,intime,outtime,status};
					model.addRow(row);
				}
							
			}
			table.setFont(new Font("Tahoma", Font.PLAIN, 20));
			table.getColumnModel().getColumn(0).setPreferredWidth(120);
			table.getColumnModel().getColumn(1).setPreferredWidth(120);
			table.getColumnModel().getColumn(2).setPreferredWidth(120);
			table.getColumnModel().getColumn(4).setPreferredWidth(100);
		
		}
		catch(Exception el)
		{
			JOptionPane.showMessageDialog(null, el);
		}
		panel.add(table);
	}

}
