package student;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.connection;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;

public class fee_form extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox rno;
	private JLabel fname,name;
	private JComboBox semester,course,branch;
	private JTextField tftotal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fee_form frame = new fee_form();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public fee_form() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Select Roll No.: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		rno = new JComboBox();
		try {
		 	Connection con=connection.getcon();
		 	Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from student");
            
            while(rs.next()) {
            	
            	int id=rs.getInt("eid");
            	String eid=Integer.toString(id);
            	rno.addItem(eid);;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		rno.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_rno = new GridBagConstraints();
		gbc_rno.insets = new Insets(0, 0, 5, 5);
		gbc_rno.fill = GridBagConstraints.HORIZONTAL;
		gbc_rno.gridx = 2;
		gbc_rno.gridy = 1;
		contentPane.add(rno, gbc_rno);
		
		JLabel lblNewLabel_1 = new JLabel("Name: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 3;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		name = new JLabel();
		name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_name = new GridBagConstraints();
		gbc_name.anchor = GridBagConstraints.WEST;
		gbc_name.insets = new Insets(0, 0, 5, 5);
		gbc_name.gridx = 2;
		gbc_name.gridy = 3;
		contentPane.add(name, gbc_name);
		
		JLabel lblNewLabel_2 = new JLabel("Father's Name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 5;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		fname = new JLabel();
		fname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_fname = new GridBagConstraints();
		gbc_fname.anchor = GridBagConstraints.WEST;
		gbc_fname.insets = new Insets(0, 0, 5, 5);
		gbc_fname.gridx = 2;
		gbc_fname.gridy = 5;
		contentPane.add(fname, gbc_fname);
		
		try {
			String rid=(String)rno.getSelectedItem();
			int id=Integer.parseInt(rid);
			Connection con=connection.getcon();
			String sel="select * from student where eid=?;";
		 	PreparedStatement st=con.prepareStatement(sel);
		 	st.setInt(1,id);
		 	ResultSet rs=st.executeQuery();
            while(rs.next()) 
            {
            	
            	name.setText(rs.getString("name"));
                fname.setText(rs.getString("father"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
            
         
        
       rno.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent ie) {
                try {
                	String rid=(String)rno.getSelectedItem();
        			int id=Integer.parseInt(rid);
        			Connection con=connection.getcon();
        			String sel="select * from student where eid=?;";
        		 	PreparedStatement st=con.prepareStatement(sel);
        		 	st.setInt(1,id);
        		 	ResultSet rs=st.executeQuery();
                    while(rs.next()) 
                    {
                    	
                    	name.setText(rs.getString("name"));
                        fname.setText(rs.getString("father"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
		
		JLabel lblNewLabel_3 = new JLabel("Course");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 7;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		course = new JComboBox();
		course.setModel(new DefaultComboBoxModel(new String[] {"B.Tech", "BBA", "BCA", "Bsc", "Msc", "MBA", "MCA", "MCom", "MA", "BA"}));
		course.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_course = new GridBagConstraints();
		gbc_course.insets = new Insets(0, 0, 5, 5);
		gbc_course.fill = GridBagConstraints.HORIZONTAL;
		gbc_course.gridx = 2;
		gbc_course.gridy = 7;
		contentPane.add(course, gbc_course);
		
		JLabel lblNewLabel_4 = new JLabel("Branch");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 1;
		gbc_lblNewLabel_4.gridy = 9;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		branch = new JComboBox();
		branch.setModel(new DefaultComboBoxModel(new String[] {"Computer Science", "Electronics", "Mechanical", "Civil", "IT"}));
		branch.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_branch = new GridBagConstraints();
		gbc_branch.insets = new Insets(0, 0, 5, 5);
		gbc_branch.fill = GridBagConstraints.HORIZONTAL;
		gbc_branch.gridx = 2;
		gbc_branch.gridy = 9;
		contentPane.add(branch, gbc_branch);
		
		JLabel lblNewLabel_5 = new JLabel("Semester");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 1;
		gbc_lblNewLabel_5.gridy = 11;
		contentPane.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		semester = new JComboBox();
		semester.setModel(new DefaultComboBoxModel(new String[] {"Semester 1", "Semester 2", "Semester 3", "Semester 4", "Semester 5", "Semester 6", "Semester 7", "Semester 8"}));
		semester.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_semester = new GridBagConstraints();
		gbc_semester.insets = new Insets(0, 0, 5, 5);
		gbc_semester.fill = GridBagConstraints.HORIZONTAL;
		gbc_semester.gridx = 2;
		gbc_semester.gridy = 11;
		contentPane.add(semester, gbc_semester);
		
		JLabel lblNewLabel_6 = new JLabel("Total Payable");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 1;
		gbc_lblNewLabel_6.gridy = 13;
		contentPane.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		tftotal = new JTextField();
		tftotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_tftotal = new GridBagConstraints();
		gbc_tftotal.insets = new Insets(0, 0, 5, 5);
		gbc_tftotal.fill = GridBagConstraints.HORIZONTAL;
		gbc_tftotal.gridx = 2;
		gbc_tftotal.gridy = 13;
		contentPane.add(tftotal, gbc_tftotal);
		
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String c=(String)course.getSelectedItem();
				String s=(String)semester.getSelectedItem();
				try
				{
					Connection con=connection.getcon();
        			
        			Statement st=con.createStatement();
        			ResultSet rs=st.executeQuery("select * from fee");
                    while(rs.next()) 
                    {
                    	String cc=rs.getString("course");
                    	String sem1=rs.getString("semester1");
                    	String sem2=rs.getString("semester2");
                    	String sem3=rs.getString("semester3");
                    	String sem4=rs.getString("semester4");
                    	String sem5=rs.getString("semester5");
                    	String sem6=rs.getString("semester6");
                    	String sem7=rs.getString("semester7");
                    	String sem8=rs.getString("semester8");
                    	if((c.equals(cc))&&(s.equals("Semester 1")))
                    	{
                    		tftotal.setText(sem1);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 2")))
                    	{
                    		tftotal.setText(sem2);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 3")))
                    	{
                    		tftotal.setText(sem3);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 4")))
                    	{
                    		tftotal.setText(sem4);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 5")))
                    	{
                    		tftotal.setText(sem5);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 6")))
                    	{
                    		tftotal.setText(sem6);
                    	}
                    	else if((c.equals(cc))&&(s.equals("Semester 7")))
                    	{
                    		tftotal.setText(sem7);
                    	}
                    	else
                    	{
                    		tftotal.setText(sem8);
                    	}
                    	
                    	
                    }
				}
				catch (Exception ea)
				{
                    ea.printStackTrace();
                }
			}
		});
		
		
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 16;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Pay Fee");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String total = tftotal.getText();
				String rollno = (String)rno.getSelectedItem();
				
	            String course1 =(String)course.getSelectedItem(); 
	            String semester1 = (String) semester.getSelectedItem();
	            String branch1 = (String) branch.getSelectedItem();
	            	            
	            try {
	            	Connection con=connection.getcon();
        			String sel="insert into collegefee values(?,?,?,?,?)";
        		 	PreparedStatement st=con.prepareStatement(sel);
        		 	st.setString(1,rollno);
        		 	st.setString(2,course1);
        		 	st.setString(3,branch1);
        		 	st.setString(4,semester1);
        		 	st.setString(5,total);
        		 	st.executeUpdate();
	                
	                JOptionPane.showMessageDialog(null, "College fee submitted successfully");
	                setVisible(false);
	            } catch (Exception cc) {
	                cc.printStackTrace();
	            }
			}
		});
		btnNewButton_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_1.gridx = 2;
		gbc_btnNewButton_1.gridy = 16;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new student_dashboard().setVisible(true);
			}
		});
		btnNewButton_2.setBackground(new Color(0, 0, 0));
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_2.gridx = 3;
		gbc_btnNewButton_2.gridy = 16;
		contentPane.add(btnNewButton_2, gbc_btnNewButton_2);
	}

}
