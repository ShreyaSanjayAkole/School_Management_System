package student;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.connection;
import login.login_home;
import staff.fee_structure;
import staff.result;

import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class student_dashboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					student_dashboard frame = new student_dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public student_dashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new new_home().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.EAST;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 1;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("About");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new about().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 2;
		gbc_btnNewButton_1.gridy = 1;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Contact Us");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new contact_us().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_2.gridx = 3;
		gbc_btnNewButton_2.gridy = 1;
		contentPane.add(btnNewButton_2, gbc_btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Query");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new student_query().setVisible(true);
			}
		});
		
		JButton btnNewButton_8 = new JButton("View Staff");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new view_staff().setVisible(true);
			}
		});
		btnNewButton_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_8 = new GridBagConstraints();
		gbc_btnNewButton_8.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_8.gridx = 4;
		gbc_btnNewButton_8.gridy = 1;
		contentPane.add(btnNewButton_8, gbc_btnNewButton_8);
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_3 = new GridBagConstraints();
		gbc_btnNewButton_3.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_3.gridx = 5;
		gbc_btnNewButton_3.gridy = 1;
		contentPane.add(btnNewButton_3, gbc_btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Fee Structure");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new fee_struc().setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_4 = new GridBagConstraints();
		gbc_btnNewButton_4.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_4.gridx = 6;
		gbc_btnNewButton_4.gridy = 1;
		contentPane.add(btnNewButton_4, gbc_btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Fee Form");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new fee_form().setVisible(true);
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_5 = new GridBagConstraints();
		gbc_btnNewButton_5.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_5.gridx = 7;
		gbc_btnNewButton_5.gridy = 1;
		contentPane.add(btnNewButton_5, gbc_btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Result");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String rno =JOptionPane.showInputDialog("Enter Roll No: ");
				new result(rno).setVisible(true);;
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_6 = new GridBagConstraints();
		gbc_btnNewButton_6.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_6.gridx = 8;
		gbc_btnNewButton_6.gridy = 1;
		contentPane.add(btnNewButton_6, gbc_btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Logout");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Do you want to logout","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					setVisible(false);
					new login_home().setVisible(true);
				}
			}
		});
		
		JButton btnNewButton_9 = new JButton("Give Attendance");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String d=new SimpleDateFormat("dd-MM-yyyy").format(new Date());
				Calendar calendar = Calendar.getInstance();
		        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		        String currentTime = sdf.format(calendar.getTime());
		        String time=currentTime.substring(0,5);
		        String startTime = "09:00";
		        String endTime = "20:00";
		        int temp=0,count=0;
		        boolean isBetweenRange = isTimeBetween(currentTime, startTime, endTime);
		        if (isBetweenRange) 
		        {
		        	String pass =JOptionPane.showInputDialog("Enter Roll No: ");
		        	int roll=Integer.parseInt(pass);
		        	try
					{
						Connection con=connection.getcon();
						
						
						String select2="select * from student_attendance;";
						Statement smtt=con.createStatement();
						ResultSet rs1=smtt.executeQuery(select2);
						while(rs1.next())
						{
							String roll_no=rs1.getString("eid");
							if(pass.equals(roll_no))
							{
								
								count++;
								
							}
							
						}
						
						String select1="select * from student;";
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery(select1);
						String pass1;
						
						while( rs.next())
						{
							int u1=rs.getInt("eid");
												
							
							if(roll==u1 && count==0)
							{
								
								String p1=rs.getString("name");
								String depart=rs.getString("depart");
								String insert="insert into student_attendance(eid,ename,dept,date,intime,status)values(?,?,?,?,?,?)";
								PreparedStatement smt=con.prepareStatement(insert);
								smt.setString(1,pass);
								smt.setString(2,p1);
								smt.setString(3,depart);
								smt.setString(4,d);
								smt.setString(5,time);
								smt.setString(6,"present");
								smt.executeUpdate();
								JOptionPane.showMessageDialog(null,"Attendance Marked");
								temp++;
							}
										
						}
						if(count>0)
						{
							JOptionPane.showMessageDialog(null,"Attendance already Marked");
						}
						else if(temp==0)
						{
							JOptionPane.showMessageDialog(null, "Roll No",
						               "Login fail", JOptionPane.WARNING_MESSAGE);
						}
						else
						{
							
						}
						
					}
					catch(Exception e1)
					{
						JOptionPane.showMessageDialog(null,e1);
					}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null,"Time out ");
		        }
				
			}

			
		});
		btnNewButton_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_9 = new GridBagConstraints();
		gbc_btnNewButton_9.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_9.gridx = 9;
		gbc_btnNewButton_9.gridy = 1;
		contentPane.add(btnNewButton_9, gbc_btnNewButton_9);
		btnNewButton_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_7 = new GridBagConstraints();
		gbc_btnNewButton_7.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton_7.gridx = 10;
		gbc_btnNewButton_7.gridy = 1;
		contentPane.add(btnNewButton_7, gbc_btnNewButton_7);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 10;
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 2;
		contentPane.add(panel, gbc_panel);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shrey\\OneDrive\\Desktop\\images\\home.jpg"));
		panel.add(lblNewLabel);
	}
	private static boolean isTimeBetween(String currentTime, String startTime, String endTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Calendar calCurrent = Calendar.getInstance();
            calCurrent.setTime(sdf.parse(currentTime));
            Calendar calStart = Calendar.getInstance();
            calStart.setTime(sdf.parse(startTime));
            Calendar calEnd = Calendar.getInstance();
            calEnd.setTime(sdf.parse(endTime));
            
            if (calCurrent.after(calStart) && calCurrent.before(calEnd)) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}
