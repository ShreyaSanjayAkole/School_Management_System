package staff;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.connection;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class enter_marks extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox selectrno,semester;
	private JTextField s1;
	private JTextField m1;
	private JTextField s2;
	private JTextField m2;
	private JTextField s3;
	private JTextField m3;
	private JTextField s4;
	private JTextField m4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					enter_marks frame = new enter_marks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public enter_marks() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Marks of Student");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 5;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Select Roll No: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 4;
		gbc_lblNewLabel_1.gridy = 3;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		selectrno = new JComboBox();
		try {
		 	Connection con=connection.getcon();
		 	Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from student");
            
            while(rs.next()) {
            	
            	int id=rs.getInt("eid");
            	String eid=Integer.toString(id);
            	selectrno.addItem(eid);;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		selectrno.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_selectrno = new GridBagConstraints();
		gbc_selectrno.insets = new Insets(0, 0, 5, 5);
		gbc_selectrno.fill = GridBagConstraints.HORIZONTAL;
		gbc_selectrno.gridx = 5;
		gbc_selectrno.gridy = 3;
		contentPane.add(selectrno, gbc_selectrno);
		
		JLabel lblNewLabel_2 = new JLabel("Select Semester:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 4;
		gbc_lblNewLabel_2.gridy = 5;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		semester = new JComboBox();
		semester.setModel(new DefaultComboBoxModel(new String[] {"Semester 1", "Semester 2", "Semester 3", "Semester 4", "Semester 5", "Semester 6", "Semester 7", "Semester 8"}));
		semester.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_semester = new GridBagConstraints();
		gbc_semester.insets = new Insets(0, 0, 5, 5);
		gbc_semester.fill = GridBagConstraints.HORIZONTAL;
		gbc_semester.gridx = 5;
		gbc_semester.gridy = 5;
		contentPane.add(semester, gbc_semester);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Subject");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 4;
		gbc_lblNewLabel_3.gridy = 7;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Marks");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 5;
		gbc_lblNewLabel_4.gridy = 7;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		s1 = new JTextField();
		s1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_s1 = new GridBagConstraints();
		gbc_s1.insets = new Insets(0, 0, 5, 5);
		gbc_s1.fill = GridBagConstraints.HORIZONTAL;
		gbc_s1.gridx = 4;
		gbc_s1.gridy = 8;
		contentPane.add(s1, gbc_s1);
		s1.setColumns(10);
		
		m1 = new JTextField();
		m1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_m1 = new GridBagConstraints();
		gbc_m1.insets = new Insets(0, 0, 5, 5);
		gbc_m1.fill = GridBagConstraints.HORIZONTAL;
		gbc_m1.gridx = 5;
		gbc_m1.gridy = 8;
		contentPane.add(m1, gbc_m1);
		m1.setColumns(10);
		
		s2 = new JTextField();
		s2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_s2 = new GridBagConstraints();
		gbc_s2.insets = new Insets(0, 0, 5, 5);
		gbc_s2.fill = GridBagConstraints.HORIZONTAL;
		gbc_s2.gridx = 4;
		gbc_s2.gridy = 10;
		contentPane.add(s2, gbc_s2);
		s2.setColumns(10);
		
		m2 = new JTextField();
		m2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_m2 = new GridBagConstraints();
		gbc_m2.insets = new Insets(0, 0, 5, 5);
		gbc_m2.fill = GridBagConstraints.HORIZONTAL;
		gbc_m2.gridx = 5;
		gbc_m2.gridy = 10;
		contentPane.add(m2, gbc_m2);
		m2.setColumns(10);
		
		s3 = new JTextField();
		s3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_s3 = new GridBagConstraints();
		gbc_s3.insets = new Insets(0, 0, 5, 5);
		gbc_s3.fill = GridBagConstraints.HORIZONTAL;
		gbc_s3.gridx = 4;
		gbc_s3.gridy = 12;
		contentPane.add(s3, gbc_s3);
		s3.setColumns(10);
		
		m3 = new JTextField();
		m3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_m3 = new GridBagConstraints();
		gbc_m3.insets = new Insets(0, 0, 5, 5);
		gbc_m3.fill = GridBagConstraints.HORIZONTAL;
		gbc_m3.gridx = 5;
		gbc_m3.gridy = 12;
		contentPane.add(m3, gbc_m3);
		m3.setColumns(10);
		
		s4 = new JTextField();
		s4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_s4 = new GridBagConstraints();
		gbc_s4.insets = new Insets(0, 0, 5, 5);
		gbc_s4.fill = GridBagConstraints.HORIZONTAL;
		gbc_s4.gridx = 4;
		gbc_s4.gridy = 14;
		contentPane.add(s4, gbc_s4);
		s4.setColumns(10);
		
		m4 = new JTextField();
		m4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_m4 = new GridBagConstraints();
		gbc_m4.insets = new Insets(0, 0, 5, 5);
		gbc_m4.fill = GridBagConstraints.HORIZONTAL;
		gbc_m4.gridx = 5;
		gbc_m4.gridy = 14;
		contentPane.add(m4, gbc_m4);
		m4.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String rno=(String)selectrno.getSelectedItem();
				int rn=Integer.parseInt(rno);
				String sem=(String)semester.getSelectedItem();
				String sub1=s1.getText();
				String mr1=m1.getText();
				String sub2=s2.getText();
				String mr2=m2.getText();
				String sub3=s3.getText();
				String mr3=m3.getText();
				String sub4=s4.getText();
				String mr4=m4.getText();
				
				 try
	                {
	               	 Connection con=connection.getcon();
	               	 String insert="insert into marks values(?,?,?,?,?,?,?,?,?,?)";
	               	 PreparedStatement ins=con.prepareStatement(insert);
	               	 ins.setInt(1, rn);
	               	 ins.setString(2,sem);
	               	 ins.setString(3,sub1);
	               	 ins.setString(4,sub2);
	               	 ins.setString(5,sub3);
	               	 ins.setString(6,sub4);
	               	 ins.setString(7,mr1);
	               	 ins.setString(8,mr2);
	               	 ins.setString(9,mr3);
	               	 ins.setString(10,mr4);
	               	 ins.executeUpdate();
	               	 JOptionPane.showMessageDialog(null, "Marks Added");
	               }
	                catch (Exception e1) {
	               	 JOptionPane.showMessageDialog(null, e1);
	                }
				
			}
		});
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 4;
		gbc_btnNewButton.gridy = 16;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancle");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_1.gridx = 5;
		gbc_btnNewButton_1.gridy = 16;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
	}

}
