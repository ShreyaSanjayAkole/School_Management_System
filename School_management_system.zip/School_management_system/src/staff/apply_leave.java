package staff;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


import com.toedter.calendar.JDateChooser;

import Email.SendEmail;
import database.connection;
import javax.swing.DefaultComboBoxModel;


public class apply_leave extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField id;
	private JTextField name;
	private JTextField phone;
	private JTextField nod;
	private JDateChooser endate,startdate;
	private JComboBox dept;
	private JTextArea reason;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					apply_leave frame = new apply_leave();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public apply_leave() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new staff_dasboard().setVisible(true);
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.insets = new Insets(0, 0, 5, 5);
		gbc_btnBack.gridx = 0;
		gbc_btnBack.gridy = 0;
		contentPane.add(btnBack, gbc_btnBack);
		
		JLabel lblNewLabel = new JLabel("Leave Application");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 3;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Employee Id :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 3;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		id = new JTextField();
		id.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_id = new GridBagConstraints();
		gbc_id.insets = new Insets(0, 0, 5, 5);
		gbc_id.fill = GridBagConstraints.HORIZONTAL;
		gbc_id.gridx = 3;
		gbc_id.gridy = 3;
		contentPane.add(id, gbc_id);
		id.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Employee Name :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 5;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		name = new JTextField();
		name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_name = new GridBagConstraints();
		gbc_name.insets = new Insets(0, 0, 5, 5);
		gbc_name.fill = GridBagConstraints.HORIZONTAL;
		gbc_name.gridx = 3;
		gbc_name.gridy = 5;
		contentPane.add(name, gbc_name);
		name.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Department :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 7;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		dept = new JComboBox();
		dept.setModel(new DefaultComboBoxModel(new String[] {"Select Department", "Computer Science", "Electronics", "Mechanical", "Civil", "IT"}));
		dept.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_dept = new GridBagConstraints();
		gbc_dept.insets = new Insets(0, 0, 5, 5);
		gbc_dept.fill = GridBagConstraints.HORIZONTAL;
		gbc_dept.gridx = 3;
		gbc_dept.gridy = 7;
		contentPane.add(dept, gbc_dept);
		
		JLabel lblNewLabel_5 = new JLabel("Mobile No. :");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 1;
		gbc_lblNewLabel_5.gridy = 9;
		contentPane.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		phone = new JTextField();
		phone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_phone = new GridBagConstraints();
		gbc_phone.insets = new Insets(0, 0, 5, 5);
		gbc_phone.fill = GridBagConstraints.HORIZONTAL;
		gbc_phone.gridx = 3;
		gbc_phone.gridy = 9;
		contentPane.add(phone, gbc_phone);
		phone.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("No. of days applied leave :");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 1;
		gbc_lblNewLabel_6.gridy = 11;
		contentPane.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		nod = new JTextField();
		nod.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_nod = new GridBagConstraints();
		gbc_nod.insets = new Insets(0, 0, 5, 5);
		gbc_nod.fill = GridBagConstraints.HORIZONTAL;
		gbc_nod.gridx = 3;
		gbc_nod.gridy = 11;
		contentPane.add(nod, gbc_nod);
		nod.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Leave Start Date :");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.gridx = 1;
		gbc_lblNewLabel_7.gridy = 13;
		contentPane.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		startdate = new JDateChooser();
		GridBagConstraints gbc_startdate = new GridBagConstraints();
		gbc_startdate.insets = new Insets(0, 0, 5, 5);
		gbc_startdate.fill = GridBagConstraints.HORIZONTAL;
		gbc_startdate.gridx = 3;
		gbc_startdate.gridy = 13;
		contentPane.add(startdate, gbc_startdate);
		
		JLabel lblNewLabel_8 = new JLabel("Leave End Date :");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 1;
		gbc_lblNewLabel_8.gridy = 15;
		contentPane.add(lblNewLabel_8, gbc_lblNewLabel_8);
		
		endate = new JDateChooser();
		GridBagConstraints gbc_endate = new GridBagConstraints();
		gbc_endate.insets = new Insets(0, 0, 5, 5);
		gbc_endate.fill = GridBagConstraints.HORIZONTAL;
		gbc_endate.gridx = 3;
		gbc_endate.gridy = 15;
		contentPane.add(endate, gbc_endate);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String eid=id.getText();
				int id=Integer.parseInt(eid);
				String ename=name.getText();
				String depart=(String)dept.getSelectedItem();
				String mobile=phone.getText();
				String nods=nod.getText();
				String rea=reason.getText();
				
				String sdate =((JTextField)startdate.getDateEditor().getUiComponent()).getText();
				String edate =((JTextField)endate.getDateEditor().getUiComponent()).getText();
				int mail=0;
				try
				{
					Connection con=connection.getcon();
					String insert="insert into leaves(id,ename,dept,mobile,nod,start,end,reason) values(?,?,?,?,?,?,?,?,?)";
					PreparedStatement ins=con.prepareStatement(insert);
	                ins.setInt(1, id);
	                ins.setString(2,ename);
	                ins.setString(3,depart);
	                ins.setString(4,mobile);
	                ins.setString(5,nods);
	                ins.setString(6,sdate);
	                ins.setString(7,edate);
	                ins.setString(8,rea);
	                ins.executeUpdate();
	                JOptionPane.showMessageDialog(null, "Successfully applied for Leave ");
				}
				catch(Exception ee)
				{
					JOptionPane.showMessageDialog(null,ee);
				}
				try
				{
					Connection con=connection.getcon();
					String select="select * from login";
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery(select);
					while(rs.next()) 
					{
						String role=rs.getString("role");
						
						if((role.equals("admin")))
						{
							String to=rs.getString("email");
							String sub="Subject: Request for Planned Leave";
							String msg= "\r\n"
									+ "I am writing to request planned leave from "+ sdate + " to "+ edate+".\r\n"
									+ "The reason for my leave is that "+ rea +".\r\n"
									+ "I kindly request your approval of my leave request, and I assure you that I will ensure a smooth transition of my work before I leave.\r\n"
									+ "\r\n"
									+ "Please let me know if you require any further information or have any questions. You can reach me by email or phone.\r\n"
									+ "\r\n"
									+ "Sincerely, \r\n"
									+ "\r\n"
									+ ename;
							 SendEmail se=new SendEmail();
							 se.SendEmail(to, msg,sub);
							 mail++;
						}
					}
					if(mail>0)
					{
						JOptionPane.showMessageDialog(null, "Successfully applied for Leave ");
						JOptionPane.showMessageDialog(null, "Leave application send to Admin ");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Failed to applied for Leave ");
					}
			    	  
			      }
			      catch(Exception ex)
			      {
			    	  JOptionPane.showMessageDialog(null,ex);
			      }
			      
				
			}
		});
		btnNewButton.setBackground(new Color(0, 255, 64));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 19;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JLabel lblNewLabel_9 = new JLabel("Reason for Leave :");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
		gbc_lblNewLabel_9.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_9.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_9.gridx = 1;
		gbc_lblNewLabel_9.gridy = 17;
		contentPane.add(lblNewLabel_9, gbc_lblNewLabel_9);
		
		reason = new JTextArea();
		reason.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GridBagConstraints gbc_reason = new GridBagConstraints();
		gbc_reason.insets = new Insets(0, 0, 5, 5);
		gbc_reason.fill = GridBagConstraints.BOTH;
		gbc_reason.gridx = 3;
		gbc_reason.gridy = 17;
		contentPane.add(reason, gbc_reason);
		
		
	}

}
