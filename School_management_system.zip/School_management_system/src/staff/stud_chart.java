package staff;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.TextAnchor;

import database.connection;

public class stud_chart extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					stud_chart frame = new stud_chart();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public stud_chart() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		showBarChart();
	}
	public void showBarChart(){
		String d=new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		int f=0,m=0,de=0,h=0,c=0;
		try
		{
			Connection con=connection.getcon();
			String select1="select * from student_attendance;";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(select1);
			String dept,date,status;
			
			while( rs.next())
			{
				
				dept=rs.getString("dept");
				date=rs.getString("date");
				status=rs.getString("status");
				if((date.equals(d))&&(dept.equalsIgnoreCase("Computer Science"))&&(status.equalsIgnoreCase("present")))
				{
					de++;
				}
				else if((date.equals(d))&&(dept.equalsIgnoreCase("Electronics"))&&(status.equalsIgnoreCase("present")))
				{
					f++;
				}
				else if((date.equals(d))&&(dept.equalsIgnoreCase("Mechanical"))&&(status.equalsIgnoreCase("present")))
				{
					m++;
				}
				else if((date.equals(d))&&(dept.equalsIgnoreCase("Civil"))&&(status.equalsIgnoreCase("present")))
				{
					h++;
				}
				else if((date.equals(d))&&(dept.equalsIgnoreCase("IT"))&&(status.equalsIgnoreCase("present")))
				{
					c++;
				}
				else
				{
					
				}
				
			}
			if(de==0 && f==0 && m==0 && h==0 && c==0)
			{
				JOptionPane.showMessageDialog(null, "No data available");
			}
		}
		catch(Exception el)
		{
			JOptionPane.showMessageDialog(null, el);
		}
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(de, "Amount", "Computer Science");
        dataset.setValue(f, "Amount", "Electronics");
        dataset.setValue(m, "Amount", "Mechanical");
        dataset.setValue(h, "Amount", "Civil");
        dataset.setValue(c, "Amount", "IT");
        
        String title="Daily Attendance ("+d+")";
        JFreeChart chart = ChartFactory.createBarChart(title,"Department","Student", 
                dataset, PlotOrientation.VERTICAL, false,true,false);
        
        CategoryPlot categoryPlot = chart.getCategoryPlot();
        //categoryPlot.setRangeGridlinePaint(Color.BLUE);
        categoryPlot.setBackgroundPaint(Color.WHITE);
        BarRenderer renderer = (BarRenderer) categoryPlot.getRenderer();
        Color clr3 = new Color(204,0,51);
        renderer.setSeriesPaint(0, clr3);
        
        NumberAxis rangeAxis = (NumberAxis) chart.getCategoryPlot().getRangeAxis() ;
        rangeAxis.setRange(0, 10); // Set the range from 1 to 10
        
        
        BarRenderer renderer1 = (BarRenderer) categoryPlot.getRenderer();
        DecimalFormat df=new DecimalFormat("##");
        renderer1.setItemLabelGenerator(new StandardCategoryItemLabelGenerator("{2}",df));
        categoryPlot.setRenderer(renderer1);
        renderer1.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.TOP_LEFT));
        renderer1.setItemLabelsVisible(true);
        chart.getCategoryPlot().setRenderer(renderer1);
        
        ChartPanel barpChartPanel = new ChartPanel(chart);
        contentPane.removeAll();
        contentPane.add(barpChartPanel, BorderLayout.CENTER);
        contentPane.validate();
        
       
    }

}
