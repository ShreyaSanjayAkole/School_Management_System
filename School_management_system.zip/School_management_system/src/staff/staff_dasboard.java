package staff;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import admin.faculty_attendance;
import admin.view_student;
import login.login_home;
import javax.swing.JLabel;

public class staff_dasboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					staff_dasboard frame = new staff_dasboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public staff_dasboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		 JMenuBar mb = new JMenuBar();
	        
	        // New Information
	        JMenu newInformation = new JMenu("New Information");
	        newInformation.setForeground(Color.BLUE);
	        mb.add(newInformation);
	        
	        
	        
	        JMenuItem studentInfo = new JMenuItem("Add New Student");
	        studentInfo.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new add_student().setVisible(true);
	        	}
	        });
	        studentInfo.setBackground(Color.WHITE);
	        
	        newInformation.add(studentInfo);
	        
	        // Details
	        JMenu details = new JMenu("View Details");
	        details.setForeground(Color.BLUE);
	        mb.add(details);
	        
	       
	        
	        JMenuItem studentdetails = new JMenuItem("View Student Details");
	        studentdetails.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new view_stud().setVisible(true);
	        	}
	        });
	        studentdetails.setBackground(Color.WHITE);
	        
	        details.add(studentdetails);
	        
	        // Leave
	        JMenu leave = new JMenu("Apply Leave");
	        leave.setForeground(Color.BLUE);
	        mb.add(leave);
	        
	        JMenuItem applyleave = new JMenuItem("Apply Leave");
	        applyleave.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new apply_leave().setVisible(true);
	        	}
	        });
	        applyleave.setBackground(Color.WHITE);
	        
	        leave.add(applyleave);
	                
	        
	        JMenu query = new JMenu("Queries");
	        query .setForeground(Color.BLUE);
	        mb.add(query );
	        
	        JMenuItem studentquery = new JMenuItem("Student Query");
	        studentquery.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new view_query().setVisible(true);
	        	}
	        });
	        studentquery.setBackground(Color.WHITE);
	       // examinationdetails.addActionListener(this);
	        query.add(studentquery);
	        
	        JMenu utility = new JMenu("Attendance");
	        utility.setForeground(Color.BLUE);
	        mb.add(utility);
	        
	        JMenuItem notepad = new JMenuItem("Give Attendance");
	        notepad.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new give_attend().setVisible(true);
	        	}
	        });
	        notepad.setBackground(Color.WHITE);
	       // notepad.addActionListener(this);
	        utility.add(notepad);
	        
	        JMenuItem stud = new JMenuItem("Student Attendance");
	        stud.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new student_atend().setVisible(true);
	        	}
	        });
	        stud.setBackground(Color.WHITE);
	       // notepad.addActionListener(this);
	        utility.add(stud);
	        
	        
	        // Exams
	        JMenu exam = new JMenu("Examination");
	        exam.setForeground(Color.BLUE);
	        mb.add(exam);
	        
	        JMenuItem examinationdetails = new JMenuItem("Examination Results");
	        examinationdetails.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new examination().setVisible(true);
	        	}
	        });
	        examinationdetails.setBackground(Color.WHITE);
	       
	        exam.add(examinationdetails);
	        
	        JMenuItem entermarks = new JMenuItem("Enter Marks");
	        entermarks.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new enter_marks().setVisible(true);
	        	}
	        });
	        entermarks.setBackground(Color.WHITE);
	        
	        exam.add(entermarks);
	        
	        // UpdateInfo
	        JMenu updateInfo = new JMenu("Update Details");
	        updateInfo.setForeground(Color.BLUE);
	        mb.add(updateInfo);
	        
	        	        
	        JMenuItem updatestudentinfo = new JMenuItem("Update Student Details");
	        updatestudentinfo.setBackground(Color.WHITE);
	        
	        updateInfo.add(updatestudentinfo);
	        
	        // fee
	        JMenu fee = new JMenu("Fee Details");
	        fee.setForeground(Color.BLUE);
	        mb.add(fee);
	        
	        JMenuItem feestructure = new JMenuItem("Fee Structure");
	        feestructure.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new fee_structure().setVisible(true);
	        	}
	        });
	        feestructure.setBackground(Color.WHITE);
	        
	        fee.add(feestructure);
	        
	        JMenuItem feeform = new JMenuItem("Student Fee Form");
	        feeform.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new student_fee_form().setVisible(true);
	        	}
	        });
	        feeform.setBackground(Color.WHITE);
	        
	        fee.add(feeform);
	        
	        
	        // about
	        JMenu about = new JMenu("About");
	        about.setForeground(Color.BLUE);
	        mb.add(about);
	        
	        JMenuItem ab = new JMenuItem("About");
	        ab.setBackground(Color.WHITE);
	       
	        about.add(ab);
	        
	        // exit
	        JMenu exit = new JMenu("Setting");
	        exit.setForeground(Color.BLUE);
	        mb.add(exit);
	        
	        JMenuItem profile = new JMenuItem("Profile");
	        profile.setBackground(Color.WHITE);
	        //ex.addActionListener(this);
	        exit.add(profile);
	        
	        JMenuItem logout = new JMenuItem("Logout");
	        logout.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		int a=JOptionPane.showConfirmDialog(null,"Do you want to logout","Select",JOptionPane.YES_NO_OPTION);
					if(a==0)
					{
						setVisible(false);
						new login_home().setVisible(true);
					}
	        	}
	        });
	        logout.setBackground(Color.WHITE);
	        //ex.addActionListener(this);
	        exit.add(logout);
	        
	        
	        
	        setJMenuBar(mb);
	        
	        setVisible(true);
	}

}
