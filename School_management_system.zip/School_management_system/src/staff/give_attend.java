package staff;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import database.connection;

public class give_attend extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					give_attend frame = new give_attend();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public give_attend() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnNewButton_2 = new JButton("back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new staff_dasboard().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_2.gridx = 1;
		gbc_btnNewButton_2.gridy = 0;
		contentPane.add(btnNewButton_2, gbc_btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("Attendance");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 5;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JButton btnNewButton = new JButton("Log In");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String d=new SimpleDateFormat("dd-MM-yyyy").format(new Date());
				Calendar calendar = Calendar.getInstance();
		        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		        String currentTime = sdf.format(calendar.getTime());
		        String time=currentTime.substring(0,5);
		        String startTime = "09:00";
		        String endTime = "10:00";
		        int temp=0;
		        boolean isBetweenRange = isTimeBetween(currentTime, startTime, endTime);
		        if (isBetweenRange) 
		        {
		        	String pass =JOptionPane.showInputDialog("Enter ID: ");
		        	int id=Integer.parseInt(pass);
		        	try
					{
						Connection con=connection.getcon();
						
						String select1="select * from teacher;";
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery(select1);
						String pass1;
						while( rs.next())
						{
							String u1=rs.getString("eid");
							int eid=Integer.parseInt(u1);
							
							if(id==eid)
							{
								String ename=rs.getString("name");
								String dept=rs.getString("depart");
								
								String insert="insert into user_attendance(eid,ename,dept,date,intime,status)values(?,?,?,?,?,?)";
								PreparedStatement smt=con.prepareStatement(insert);
								smt.setString(1,pass);
								smt.setString(2,ename);
								smt.setString(3,dept);
								smt.setString(4,d);
								smt.setString(5,time);
								smt.setString(6,"present");
								smt.executeUpdate();
								JOptionPane.showMessageDialog(null,"Attendance Marked");
								temp++;
							}
										
						}
						if(temp==0)
						{
							JOptionPane.showMessageDialog(null, "Invalid username or Password!",
						               "Login fail", JOptionPane.WARNING_MESSAGE);
						}
						
					}
					catch(Exception e1)
					{
						JOptionPane.showMessageDialog(null,e1);
					}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null,"Time out ");
		        }
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 3;
		gbc_btnNewButton.gridy = 6;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Log Out");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Calendar calendar = Calendar.getInstance();
		        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		        String currentTime = sdf.format(calendar.getTime());
		        String time=currentTime.substring(0,5);
		        String startTime = "18:00";
		        String endTime = "20:00";
		        int temp=0;
		        boolean isBetweenRange = isTimeBetween(currentTime, startTime, endTime);
		        if (isBetweenRange) 
		        {
		        	String pass =JOptionPane.showInputDialog("Enter ID: ");
		        	int id=Integer.parseInt(pass);
		        	try
					{
						Connection con=connection.getcon();
						
						String select1="select * from teacher;";
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery(select1);
						String pass1;
						while( rs.next())
						{
							String u1=rs.getString("eid");
							int eid=Integer.parseInt(u1);
							
							if(id==eid)
							{
								
								
								String update="update user_attendance set outtime=? where eid=?";
								PreparedStatement smt=con.prepareStatement(update);
								smt.setString(1,time);
								smt.setString(2, pass);
								smt.executeUpdate();
								JOptionPane.showMessageDialog(null,"Log out ");
								temp++;
							}
							
											
						}
						if(temp==0)
						{
							JOptionPane.showMessageDialog(null, "Invalid username or Password!",
						               "Login fail", JOptionPane.WARNING_MESSAGE);
						}
						
					}
					catch(Exception e1)
					{
						JOptionPane.showMessageDialog(null,e1);
					}
		        }
		        else
		        {
		        	JOptionPane.showMessageDialog(null,"Time out ");
		        }
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_1.gridx = 7;
		gbc_btnNewButton_1.gridy = 6;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
	}
	private static boolean isTimeBetween(String currentTime, String startTime, String endTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Calendar calCurrent = Calendar.getInstance();
            calCurrent.setTime(sdf.parse(currentTime));
            Calendar calStart = Calendar.getInstance();
            calStart.setTime(sdf.parse(startTime));
            Calendar calEnd = Calendar.getInstance();
            calEnd.setTime(sdf.parse(endTime));
            
            if (calCurrent.after(calStart) && calCurrent.before(calEnd)) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
	}

}
