package staff;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import admin.add_faculty;
import admin.admin_dashboard;
import admin.update_faculty;
import database.connection;

public class view_stud extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JComboBox empid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					view_stud frame = new view_stud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public view_stud() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 850);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Search by Roll No: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		empid = new JComboBox();
		try {
		 	Connection con=connection.getcon();
		 	Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from student");
            
            while(rs.next()) {
            	
            	int id=rs.getInt("eid");
            	String eid=Integer.toString(id);
            	empid.addItem(eid);;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		empid.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_empid = new GridBagConstraints();
		gbc_empid.gridwidth = 2;
		gbc_empid.insets = new Insets(0, 0, 5, 5);
		gbc_empid.fill = GridBagConstraints.HORIZONTAL;
		gbc_empid.gridx = 2;
		gbc_empid.gridy = 1;
		contentPane.add(empid, gbc_empid);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
				table.setModel(new DefaultTableModel(
						new Object[][] {
							{"ID", "Name", "Address", "Email", "Qualification","Class XII","Class X", "Father name", "DOB", "Phone no.", "Aadhar No.", "Department"},
						},
						new String[] {
								"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column","New column","New column"
						}
					));
				String f=(String)empid.getSelectedItem();
				int temp=Integer.parseInt(f);
				int c=0;
				try
				{
					
					Connection con=connection.getcon();
					String select1="select * from student;";
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery(select1);
					ResultSetMetaData rsmd=rs.getMetaData();
					DefaultTableModel model= (DefaultTableModel) table.getModel();
					int cols=rsmd.getColumnCount();
					String[] colname=new String[cols];
					for(int i=0;i<cols;i++)
					{
						colname[i]=rsmd.getColumnName(i+1);
										
					}
					model.setColumnIdentifiers(colname);
					
					String Name, Address, Email, Qualification,c12,c10, Father_name, DOB,Department;
					int ID;
					long Phone_no,Aadhar_No;
					while( rs.next())
					{
						ID=rs.getInt("eid");
						Name=rs.getString("name");
						Address=rs.getString("address");
						Email=rs.getString("email");
						Qualification=rs.getString("Qua");
						c12=rs.getString("class_xii");
						c10=rs.getString("class_x");
						Father_name=rs.getString("father");
						DOB=rs.getString("dob");
						Phone_no=rs.getLong("phone");
						Aadhar_No=rs.getLong("adhar");
						Department=rs.getString("depart");
						if(temp==ID)
						{
							String emp=Integer.toString(ID);
							String p=Long.toString(Phone_no);
							String a=Long.toString(Aadhar_No);
							String[] row= {emp, Name, Address, Email, Qualification,c12,c10, Father_name, DOB, p, a, Department};
							
							model.addRow(row);
							c++;
							
						}
							
					}
					
					if(c==0)
					{
						JOptionPane.showMessageDialog(null, "No Data available");
					}
					
					table.getColumnModel().getColumn(1).setPreferredWidth(100);
					table.getColumnModel().getColumn(2).setPreferredWidth(100);
					table.getColumnModel().getColumn(3).setPreferredWidth(200);
					table.getColumnModel().getColumn(8).setPreferredWidth(150);
					table.getColumnModel().getColumn(9).setPreferredWidth(150);
					table.getColumnModel().getColumn(10).setPreferredWidth(150);
					table.getColumnModel().getColumn(11).setPreferredWidth(150);
					
				}
				catch(Exception el)
				{
					JOptionPane.showMessageDialog(null, el);
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 4;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Print");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					table.print();
				}
				catch(Exception el)
				{
					JOptionPane.showMessageDialog(null, el);
				}
				

			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 2;
		gbc_btnNewButton_1.gridy = 4;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Add");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new add_faculty().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_2.gridx = 3;
		gbc_btnNewButton_2.gridy = 4;
		contentPane.add(btnNewButton_2, gbc_btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Update");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new update_faculty().setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_3 = new GridBagConstraints();
		gbc_btnNewButton_3.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_3.gridx = 4;
		gbc_btnNewButton_3.gridy = 4;
		contentPane.add(btnNewButton_3, gbc_btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Back");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new staff_dasboard().setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton_4 = new GridBagConstraints();
		gbc_btnNewButton_4.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_4.gridx = 5;
		gbc_btnNewButton_4.gridy = 4;
		contentPane.add(btnNewButton_4, gbc_btnNewButton_4);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 13;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 6;
		contentPane.add(panel, gbc_panel);
		
		table = new JTable();
		table.setModel(new DefaultTableModel());
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		panel.add(table);
	}

}
