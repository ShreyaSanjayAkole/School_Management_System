package staff;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import database.connection;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class mark_attend extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private List<String> studentList = new ArrayList<>();
	private ArrayList<JCheckBox> checkBoxList = new ArrayList<>();
	private List<String> temp = new ArrayList<>();
    private JPanel panel;
    private JButton btnNewButton_1;
    int c=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mark_attend frame = new mark_attend();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mark_attend() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new staff_dasboard().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 0;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Mark Student Attendance");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		btnNewButton_1 = new JButton("Submit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getSelectedItems();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 7;
		gbc_btnNewButton_1.gridy = 1;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
		
		panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 12;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 3;
		contentPane.add(panel, gbc_panel);
		panel.setLayout(new GridLayout(0, 1));
		
		try
		{
			Connection con=connection.getcon();
			String select1="select * from student;";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(select1);
			while(rs.next())
			{
				
				String name=rs.getString("name");
				 studentList.add(name);
				 JCheckBox checkBox = new JCheckBox(name);
				 checkBoxList.add(checkBox);
				         
			}
				 			 
	        
			
		}
		catch(Exception el)
		{
			JOptionPane.showMessageDialog(null, el);
		}
		
		for (JCheckBox checkBox : checkBoxList) {
            panel.add(checkBox);
        }
		
	}
	private void getSelectedItems() {
		int it=0;
        ArrayList<String> selectedItems = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxList) {
            if (checkBox.isSelected()) {
                selectedItems.add(checkBox.getText());
                it++;
            }
            
        }
        if(it==0)
        {
        	JOptionPane.showMessageDialog(null,"No Student is selected");
        }
        else
        {
        	 String d=new SimpleDateFormat("dd-MM-yyyy").format(new Date());
     		Calendar calendar = Calendar.getInstance();
             SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
             String currentTime = sdf.format(calendar.getTime());
             String time=currentTime.substring(0,5);
             
             	for (int i = 0; i < selectedItems.size(); i++) 
                 {
                     String item = selectedItems.get(i);
                     try
                     {
                     	Connection con=connection.getcon();
                     	String select1="select * from student;";
         				Statement st=con.createStatement();
         				ResultSet rs=st.executeQuery(select1);
         				while( rs.next())
         				{
         					
         					String p1=rs.getString("name");
         					
         					if(item.equals(p1))
         					{
         						int u1=rs.getInt("eid");
         						String depart=rs.getString("depart");
             					String roll=Integer.toString(u1);
         						String insert="insert into student_attendance(eid,ename,dept,date,intime,status)values(?,?,?,?,?,?)";
             					PreparedStatement smt=con.prepareStatement(insert);
             					smt.setString(1,roll);
             					smt.setString(2,p1);
             					smt.setString(3,depart);
             					smt.setString(4,d);
             					smt.setString(5,time);
             					smt.setString(6,"present");
             					smt.executeUpdate();
             					c++;
             					
             					
         					}
         					
         				}
         				
         				                	
                     }
                     catch(Exception el)
             		{
             			JOptionPane.showMessageDialog(null, el);
             		}
                 }
             	if(c>0)
 				{
 					JOptionPane.showMessageDialog(null,"Attendance Marked");
 				}
             }
        
       
        
	}

}
