package parrent;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import student.student_dashboard;

public class parent_about extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					parent_about frame = new parent_about();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public parent_about() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnNewButton = new JButton("<-");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new parent_dashboard().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 0;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Numetry Technology");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Our Mission");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 2;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JTextArea mission = new JTextArea();
		GridBagConstraints gbc_mission = new GridBagConstraints();
		String m="Numetry Technologies endeavors to be the source that delivers success and competitive \r\n"
				+ "\r\n"
				+ "advantage to your business by employing the best industry practices and a team of\r\n "
				+ "\r\n"
				+ "experts to deliver world-class innovative products and services with value for money\r\n"
				+ "\r\n"
				+ " to our customers.";
		mission.setText(m);
		mission.setFont(new Font("Tahoma", Font.PLAIN, 15));
		gbc_mission.gridwidth = 10;
		gbc_mission.insets = new Insets(0, 0, 5, 0);
		gbc_mission.fill = GridBagConstraints.BOTH;
		gbc_mission.gridx = 1;
		gbc_mission.gridy = 3;
		contentPane.add(mission, gbc_mission);
		
		JLabel lblNewLabel_2 = new JLabel("Our Vission");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 4;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		JTextArea vission = new JTextArea();
		GridBagConstraints gbc_vission = new GridBagConstraints();
		String v="To become the industry leader in providing bespoke technology services industry-wide, \r\n"
				+ "\r\n"
				+ "globally by helping businesses in all our capacity to reach their truest potential via\r\n"
				+ "\r\n"
				+ " creating a thriving work environment, healthy work culture, and promoting growth and \r\n"
				+ "\r\n"
				+ "development of the team.";
		vission.setText(v);
		vission.setFont(new Font("Tahoma", Font.PLAIN, 15));
		gbc_vission.gridwidth = 10;
		gbc_vission.insets = new Insets(0, 0, 5, 0);
		gbc_vission.fill = GridBagConstraints.BOTH;
		gbc_vission.gridx = 1;
		gbc_vission.gridy = 5;
		contentPane.add(vission, gbc_vission);
	}

}
