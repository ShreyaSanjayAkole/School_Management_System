package parrent;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.login_home;
import staff.add_student;
import staff.apply_leave;
import staff.enter_marks;
import staff.examination;
import staff.fee_structure;
import staff.give_attend;
import staff.student_atend;
import staff.student_fee_form;
import staff.view_query;
import staff.view_stud;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class pdashboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pdashboard frame = new pdashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pdashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shrey\\OneDrive\\Desktop\\images\\home.jpg"));
		contentPane.add(lblNewLabel);
		 JMenuBar mb = new JMenuBar();
	        
	        // New Information
	        JMenu newInformation = new JMenu("Home");
	        newInformation.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        newInformation.setForeground(Color.BLUE);
	        mb.add(newInformation);
	        
	        
	        
	        JMenuItem studentInfo = new JMenuItem("Home");
	        studentInfo.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        studentInfo.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new parent_home().setVisible(true);
	        	}
	        });
	        studentInfo.setBackground(Color.WHITE);
	        
	        newInformation.add(studentInfo);
	        
	        // Details
	        JMenu details = new JMenu("About");
	        details.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        details.setForeground(Color.BLUE);
	        mb.add(details);
	        
	       
	        
	        JMenuItem studentdetails = new JMenuItem("About");
	        studentdetails.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        studentdetails.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new parent_about().setVisible(true);
	        	}
	        });
	        studentdetails.setBackground(Color.WHITE);
	        
	        details.add(studentdetails);
	        
	        // Leave
	        JMenu leave = new JMenu("Contact Us");
	        leave.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        leave.setForeground(Color.BLUE);
	        mb.add(leave);
	        
	        JMenuItem applyleave = new JMenuItem("Contact Us");
	        applyleave.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        applyleave.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new parent_contact().setVisible(true);
	        	}
	        });
	        applyleave.setBackground(Color.WHITE);
	        
	        leave.add(applyleave);
	                
	        
	        JMenu query = new JMenu("Universities");
	        query.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        query .setForeground(Color.BLUE);
	        mb.add(query );
	        
	        JMenuItem studentquery = new JMenuItem("Schools");
	        studentquery.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        studentquery.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new view_query().setVisible(true);
	        	}
	        });
	        studentquery.setBackground(Color.WHITE);
	       // examinationdetails.addActionListener(this);
	        query.add(studentquery);
	        
	        JMenuItem college = new JMenuItem("Colleges");
	        college.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        college.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new view_query().setVisible(true);
	        	}
	        });
	        college.setBackground(Color.WHITE);
	       // examinationdetails.addActionListener(this);
	        query.add(college);
	        
	        JMenu utility = new JMenu("Achivements");
	        utility.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        utility.setForeground(Color.BLUE);
	        mb.add(utility);
	        
	        JMenuItem notepad = new JMenuItem("Awards & Certifications");
	        notepad.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        notepad.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new give_attend().setVisible(true);
	        	}
	        });
	        notepad.setBackground(Color.WHITE);
	       // notepad.addActionListener(this);
	        utility.add(notepad);
	        
	        
	        
	        
	        // Exams
	        JMenu exam = new JMenu("Academics");
	        exam.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        exam.setForeground(Color.BLUE);
	        mb.add(exam);
	        
	        JMenuItem examinationdetails = new JMenuItem("Career");
	        examinationdetails.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        examinationdetails.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new examination().setVisible(true);
	        	}
	        });
	        examinationdetails.setBackground(Color.WHITE);
	       
	        exam.add(examinationdetails);
	        
	        JMenuItem entermarks = new JMenuItem("Faculties");
	        entermarks.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        entermarks.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new enter_marks().setVisible(true);
	        	}
	        });
	        entermarks.setBackground(Color.WHITE);
	        
	        exam.add(entermarks);
	        
	        JMenuItem notice = new JMenuItem("Notice");
	        notice.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        notice.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new enter_marks().setVisible(true);
	        	}
	        });
	        notice.setBackground(Color.WHITE);
	        
	        exam.add(notice);
	        
	        
	        JMenuItem fee = new JMenuItem("Fee Structure");
	        fee.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        notice.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new enter_marks().setVisible(true);
	        	}
	        });
	        fee.setBackground(Color.WHITE);
	        
	        exam.add(fee);
	        
	        JMenuItem result = new JMenuItem("Result");
	        result.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        result.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		new enter_marks().setVisible(true);
	        	}
	        });
	        result.setBackground(Color.WHITE);
	        
	        exam.add(result);
	        
	        // UpdateInfo
	        JMenu updateInfo = new JMenu("Reviews");
	        updateInfo.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        updateInfo.setForeground(Color.BLUE);
	        mb.add(updateInfo);
	        
	        	        
	        JMenuItem updatestudentinfo = new JMenuItem("Reviews and Ratings");
	        updatestudentinfo.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        updatestudentinfo.setBackground(Color.WHITE);
	        
	        updateInfo.add(updatestudentinfo);
	        
	        // fee
	        
	        
	        
	        
	        // exit
	        JMenu exit = new JMenu("Setting");
	        exit.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        exit.setForeground(Color.BLUE);
	        mb.add(exit);
	        
	        	        
	        JMenuItem logout = new JMenuItem("Logout");
	        logout.setFont(new Font("Segoe UI", Font.PLAIN, 20));
	        logout.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		
						setVisible(false);
						new login_home().setVisible(true);
					
	        	}
	        });
	        logout.setBackground(Color.WHITE);
	        //ex.addActionListener(this);
	        exit.add(logout);
	        
	        
	        
	        setJMenuBar(mb);
	        
	        setVisible(true);
	}

}
