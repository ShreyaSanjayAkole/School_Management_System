package login;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import database.connection;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import java.awt.Color;

public class sign_up extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField username;
	private JTextField email;
	private JTextField password;
	private JTextField confirm;
	private JComboBox role;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sign_up frame = new sign_up();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public sign_up() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Sign Up");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 4;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("Full Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 3;
		gbc_lblNewLabel_1.gridy = 3;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		name = new JTextField();
		name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_name = new GridBagConstraints();
		gbc_name.gridwidth = 4;
		gbc_name.insets = new Insets(0, 0, 5, 5);
		gbc_name.fill = GridBagConstraints.HORIZONTAL;
		gbc_name.gridx = 4;
		gbc_name.gridy = 3;
		contentPane.add(name, gbc_name);
		name.setColumns(10);
		
		
		
		JLabel lblNewLabel_6 = new JLabel("Role");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 3;
		gbc_lblNewLabel_6.gridy = 5;
		contentPane.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		role = new JComboBox();
		role.setModel(new DefaultComboBoxModel(new String[] {"Staff", "Student"}));
		role.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_role = new GridBagConstraints();
		gbc_role.gridwidth = 4;
		gbc_role.insets = new Insets(0, 0, 5, 5);
		gbc_role.fill = GridBagConstraints.HORIZONTAL;
		gbc_role.gridx = 4;
		gbc_role.gridy = 5;
		contentPane.add(role, gbc_role);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 3;
		gbc_lblNewLabel_3.gridy = 7;
		contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		email = new JTextField();
		email.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_email = new GridBagConstraints();
		gbc_email.gridwidth = 4;
		gbc_email.insets = new Insets(0, 0, 5, 5);
		gbc_email.fill = GridBagConstraints.HORIZONTAL;
		gbc_email.gridx = 4;
		gbc_email.gridy = 7;
		contentPane.add(email, gbc_email);
		email.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 3;
		gbc_lblNewLabel_2.gridy = 9;
		contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		username = new JTextField();
		username.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_username = new GridBagConstraints();
		gbc_username.gridwidth = 4;
		gbc_username.insets = new Insets(0, 0, 5, 5);
		gbc_username.fill = GridBagConstraints.HORIZONTAL;
		gbc_username.gridx = 4;
		gbc_username.gridy = 9;
		contentPane.add(username, gbc_username);
		username.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 3;
		gbc_lblNewLabel_4.gridy = 11;
		contentPane.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		password = new JTextField();
		password.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_password = new GridBagConstraints();
		gbc_password.gridwidth = 4;
		gbc_password.insets = new Insets(0, 0, 5, 5);
		gbc_password.fill = GridBagConstraints.HORIZONTAL;
		gbc_password.gridx = 4;
		gbc_password.gridy = 11;
		contentPane.add(password, gbc_password);
		password.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Note: Password must like Abc@123");
		lblNewLabel_7.setForeground(new Color(255, 0, 0));
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.gridx = 4;
		gbc_lblNewLabel_7.gridy = 12;
		contentPane.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		JLabel lblNewLabel_5 = new JLabel("confirm Password");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 3;
		gbc_lblNewLabel_5.gridy = 14;
		contentPane.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		confirm = new JTextField();
		confirm.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_confirm = new GridBagConstraints();
		gbc_confirm.gridwidth = 4;
		gbc_confirm.insets = new Insets(0, 0, 5, 5);
		gbc_confirm.fill = GridBagConstraints.HORIZONTAL;
		gbc_confirm.gridx = 4;
		gbc_confirm.gridy = 14;
		contentPane.add(confirm, gbc_confirm);
		confirm.setColumns(10);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
							
				String n=name.getText();
				String r=(String)role.getSelectedItem();
				String u=username.getText();
				String p=password.getText();
				String c=confirm.getText();
				String mail=email.getText();
				
				String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
				int upper=0,lower=0,special=0,digit=0,len=0,count=0;
				
					if(p.length() > 8)
					{
						len++;
						for (int temp = 0; temp < p.length(); temp++)
						{
							
							if((Character.isUpperCase(p.charAt(temp))))
							{
								upper++;
							}
							else if(Character.isLowerCase(p.charAt(temp)))
							{
								lower++;
							}
							else if(Character.isDigit(p.charAt(temp)))
							{
								digit++;
							}
							else if(!(Character.isWhitespace(p.charAt(temp))))
							{
								special++;
							}
							else
							{
								count++;
							}
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Password must be greater thar 8 character");
					}
					if(upper>0 && lower>0 && digit>0 && special>0)
					{
						if(p.equals(c))
						{	
							if(mail.matches(emailPattern))
							{
								try
								{	
									Connection con = connection.getcon();						
									String insert ="insert into login(name,username,password,role,email) values(?,?,?,?,?)";
									PreparedStatement ins=con.prepareStatement(insert);
									ins.setString(1,n);
									ins.setString(2,u);
						            ins.setString(3,p);
						            ins.setString(4,r);
						            ins.setString(5,mail);
						            ins.executeUpdate();
						            JOptionPane.showMessageDialog(null,"Registered Successfully  ");
								}
								catch(Exception e1)
								{
									JOptionPane.showMessageDialog(null,e1);
								}
								
							}
							else
							{
								JOptionPane.showMessageDialog(null,"Enter Valid Email");
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null,"Password Doesn't match");
						}	
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Invalid Password");
					}
					
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 4;
		gbc_btnNewButton.gridy = 16;
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new login_home().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 4;
		gbc_btnNewButton_1.gridy = 17;
		contentPane.add(btnNewButton_1, gbc_btnNewButton_1);
	}

}
